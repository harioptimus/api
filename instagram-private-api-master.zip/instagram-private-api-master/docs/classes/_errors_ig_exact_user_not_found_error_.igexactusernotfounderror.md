> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-exact-user-not-found-error"](../modules/_errors_ig_exact_user_not_found_error_.md) / [IgExactUserNotFoundError](_errors_ig_exact_user_not_found_error_.igexactusernotfounderror.md) /

# Class: IgExactUserNotFoundError

## Hierarchy

- [IgClientError](_errors_ig_client_error_.igclienterror.md)

- **IgExactUserNotFoundError**

## Index

### Constructors

- [constructor](_errors_ig_exact_user_not_found_error_.igexactusernotfounderror.md#constructor)

## Constructors

### constructor

\+ **new IgExactUserNotFoundError**(): _[IgExactUserNotFoundError](\_errors_ig_exact_user_not_found_error_.igexactusernotfounderror.md)\_

_Overrides [IgClientError](\_errors_ig_client_error_.igclienterror.md).[constructor](_errors_ig_client_error_.igclienterror.md#constructor)\_

_Defined in [errors/ig-exact-user-not-found-error.ts:3](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/errors/ig-exact-user-not-found-error.ts#L3)_

**Returns:** _[IgExactUserNotFoundError](\_errors_ig_exact_user_not_found_error_.igexactusernotfounderror.md)\_
