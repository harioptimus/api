> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-user-id-not-found.error"](../modules/_errors_ig_user_id_not_found_error_.md) / [IgUserIdNotFoundError](_errors_ig_user_id_not_found_error_.iguseridnotfounderror.md) /

# Class: IgUserIdNotFoundError

## Hierarchy

- [IgClientError](_errors_ig_client_error_.igclienterror.md)

- **IgUserIdNotFoundError**

## Index

### Constructors

- [constructor](_errors_ig_user_id_not_found_error_.iguseridnotfounderror.md#constructor)

## Constructors

### constructor

\+ **new IgUserIdNotFoundError**(): _[IgUserIdNotFoundError](\_errors_ig_user_id_not_found_error_.iguseridnotfounderror.md)\_

_Overrides [IgClientError](\_errors_ig_client_error_.igclienterror.md).[constructor](_errors_ig_client_error_.igclienterror.md#constructor)\_

_Defined in [errors/ig-user-id-not-found.error.ts:3](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/errors/ig-user-id-not-found.error.ts#L3)_

**Returns:** _[IgUserIdNotFoundError](\_errors_ig_user_id_not_found_error_.iguseridnotfounderror.md)\_
