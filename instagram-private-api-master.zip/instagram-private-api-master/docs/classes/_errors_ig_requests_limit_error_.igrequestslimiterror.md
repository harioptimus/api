> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-requests-limit.error"](../modules/_errors_ig_requests_limit_error_.md) / [IgRequestsLimitError](_errors_ig_requests_limit_error_.igrequestslimiterror.md) /

# Class: IgRequestsLimitError

## Hierarchy

- [IgClientError](_errors_ig_client_error_.igclienterror.md)

- **IgRequestsLimitError**

## Index

### Constructors

- [constructor](_errors_ig_requests_limit_error_.igrequestslimiterror.md#constructor)

## Constructors

### constructor

\+ **new IgRequestsLimitError**(): _[IgRequestsLimitError](\_errors_ig_requests_limit_error_.igrequestslimiterror.md)\_

_Overrides [IgClientError](\_errors_ig_client_error_.igclienterror.md).[constructor](_errors_ig_client_error_.igclienterror.md#constructor)\_

_Defined in [errors/ig-requests-limit.error.ts:3](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/errors/ig-requests-limit.error.ts#L3)_

**Returns:** _[IgRequestsLimitError](\_errors_ig_requests_limit_error_.igrequestslimiterror.md)\_
