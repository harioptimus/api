> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["core/request"](_core_request_.md) /

# External module: "core/request"

## Index

### Classes

* [Request](../classes/_core_request_.request.md)