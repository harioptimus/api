> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["core/state"](_core_state_.md) /

# External module: "core/state"

## Index

### Classes

* [State](../classes/_core_state_.state.md)