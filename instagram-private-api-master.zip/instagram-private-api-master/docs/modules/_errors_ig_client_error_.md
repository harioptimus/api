> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-client.error"](_errors_ig_client_error_.md) /

# External module: "errors/ig-client.error"

## Index

### Classes

* [IgClientError](../classes/_errors_ig_client_error_.igclienterror.md)