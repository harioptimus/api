> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-cookie-not-found.error"](_errors_ig_cookie_not_found_error_.md) /

# External module: "errors/ig-cookie-not-found.error"

## Index

### Classes

* [IgCookieNotFoundError](../classes/_errors_ig_cookie_not_found_error_.igcookienotfounderror.md)