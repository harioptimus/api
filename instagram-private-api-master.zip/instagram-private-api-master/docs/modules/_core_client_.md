> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["core/client"](_core_client_.md) /

# External module: "core/client"

## Index

### Classes

- [IgApiClient](../classes/_core_client_.igapiclient.md)
