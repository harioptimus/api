> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-challenge-wrong-code.error"](_errors_ig_challenge_wrong_code_error_.md) /

# External module: "errors/ig-challenge-wrong-code.error"

## Index

### Classes

* [IgChallengeWrongCodeError](../classes/_errors_ig_challenge_wrong_code_error_.igchallengewrongcodeerror.md)