> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-action-spam.error"](_errors_ig_action_spam_error_.md) /

# External module: "errors/ig-action-spam.error"

## Index

### Classes

* [IgActionSpamError](../classes/_errors_ig_action_spam_error_.igactionspamerror.md)