> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["core/feed.factory"](_core_feed_factory_.md) /

# External module: "core/feed.factory"

## Index

### Classes

* [FeedFactory](../classes/_core_feed_factory_.feedfactory.md)