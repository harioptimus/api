> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["entities/live.entity"](_entities_live_entity_.md) /

# External module: "entities/live.entity"

## Index

### Classes

* [LiveEntity](../classes/_entities_live_entity_.liveentity.md)