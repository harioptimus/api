> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["core/feed"](_core_feed_.md) /

# External module: "core/feed"

## Index

### Classes

* [Feed](../classes/_core_feed_.feed.md)