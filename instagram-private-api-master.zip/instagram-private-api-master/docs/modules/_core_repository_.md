> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["core/repository"](_core_repository_.md) /

# External module: "core/repository"

## Index

### Classes

* [Repository](../classes/_core_repository_.repository.md)