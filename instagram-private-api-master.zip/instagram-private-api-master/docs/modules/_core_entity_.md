> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["core/entity"](_core_entity_.md) /

# External module: "core/entity"

## Index

### Classes

* [Entity](../classes/_core_entity_.entity.md)