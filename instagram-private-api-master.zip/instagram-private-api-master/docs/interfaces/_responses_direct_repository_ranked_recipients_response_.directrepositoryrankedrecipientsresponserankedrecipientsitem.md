> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/direct.repository.ranked-recipients.response"](../modules/_responses_direct_repository_ranked_recipients_response_.md) / [DirectRepositoryRankedRecipientsResponseRankedRecipientsItem](_responses_direct_repository_ranked_recipients_response_.directrepositoryrankedrecipientsresponserankedrecipientsitem.md) /

# Interface: DirectRepositoryRankedRecipientsResponseRankedRecipientsItem

## Hierarchy

- **DirectRepositoryRankedRecipientsResponseRankedRecipientsItem**

## Index

### Properties

- [thread](_responses_direct_repository_ranked_recipients_response_.directrepositoryrankedrecipientsresponserankedrecipientsitem.md#optional-thread)
- [user](_responses_direct_repository_ranked_recipients_response_.directrepositoryrankedrecipientsresponserankedrecipientsitem.md#optional-user)

## Properties

### `Optional` thread

• **thread**? : _[DirectRepositoryRankedRecipientsResponseThread](\_responses_direct_repository_ranked_recipients_response_.directrepositoryrankedrecipientsresponsethread.md)\_

_Defined in [responses/direct.repository.ranked-recipients.response.ts:11](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct.repository.ranked-recipients.response.ts#L11)_

---

### `Optional` user

• **user**? : _[DirectRepositoryRankedRecipientsResponseUser](\_responses_direct_repository_ranked_recipients_response_.directrepositoryrankedrecipientsresponseuser.md)\_

_Defined in [responses/direct.repository.ranked-recipients.response.ts:10](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct.repository.ranked-recipients.response.ts#L10)_
