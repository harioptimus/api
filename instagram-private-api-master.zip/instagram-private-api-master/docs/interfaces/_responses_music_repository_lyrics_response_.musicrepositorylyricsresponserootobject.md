> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/music.repository.lyrics.response"](../modules/_responses_music_repository_lyrics_response_.md) / [MusicRepositoryLyricsResponseRootObject](_responses_music_repository_lyrics_response_.musicrepositorylyricsresponserootobject.md) /

# Interface: MusicRepositoryLyricsResponseRootObject

## Hierarchy

- **MusicRepositoryLyricsResponseRootObject**

## Index

### Properties

- [lyrics](_responses_music_repository_lyrics_response_.musicrepositorylyricsresponserootobject.md#lyrics)
- [status](_responses_music_repository_lyrics_response_.musicrepositorylyricsresponserootobject.md#status)

## Properties

### lyrics

• **lyrics**: _[MusicRepositoryLyricsResponseLyrics](\_responses_music_repository_lyrics_response_.musicrepositorylyricsresponselyrics.md)\_

_Defined in [responses/music.repository.lyrics.response.ts:2](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/music.repository.lyrics.response.ts#L2)_

---

### status

• **status**: _string_

_Defined in [responses/music.repository.lyrics.response.ts:3](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/music.repository.lyrics.response.ts#L3)_
