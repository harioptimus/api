> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/timeline.feed.response"](../modules/_responses_timeline_feed_response_.md) / [TimelineFeedResponseUsertags](_responses_timeline_feed_response_.timelinefeedresponseusertags.md) /

# Interface: TimelineFeedResponseUsertags

## Hierarchy

- **TimelineFeedResponseUsertags**

## Index

### Properties

- [in](_responses_timeline_feed_response_.timelinefeedresponseusertags.md#in)

## Properties

### in

• **in**: _[TimelineFeedResponseInItem](\_responses_timeline_feed_response_.timelinefeedresponseinitem.md)[]\_

_Defined in [responses/timeline.feed.response.ts:228](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/timeline.feed.response.ts#L228)_
