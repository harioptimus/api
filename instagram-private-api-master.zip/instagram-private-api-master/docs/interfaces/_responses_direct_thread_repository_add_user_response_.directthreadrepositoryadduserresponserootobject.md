> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/direct-thread.repository.add-user.response"](../modules/_responses_direct_thread_repository_add_user_response_.md) / [DirectThreadRepositoryAddUserResponseRootObject](_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponserootobject.md) /

# Interface: DirectThreadRepositoryAddUserResponseRootObject

## Hierarchy

- **DirectThreadRepositoryAddUserResponseRootObject**

## Index

### Properties

- [status](_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponserootobject.md#status)
- [thread](_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponserootobject.md#thread)

## Properties

### status

• **status**: _string_

_Defined in [responses/direct-thread.repository.add-user.response.ts:3](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.add-user.response.ts#L3)_

---

### thread

• **thread**: _[DirectThreadRepositoryAddUserResponseThread](\_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponsethread.md)\_

_Defined in [responses/direct-thread.repository.add-user.response.ts:2](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.add-user.response.ts#L2)_
