> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/location.feed.response"](../modules/_responses_location_feed_response_.md) / [LocationFeedResponseImage_versions2](_responses_location_feed_response_.locationfeedresponseimage_versions2.md) /

# Interface: LocationFeedResponseImage_versions2

## Hierarchy

- **LocationFeedResponseImage_versions2**

## Index

### Properties

- [candidates](_responses_location_feed_response_.locationfeedresponseimage_versions2.md#candidates)

## Properties

### candidates

• **candidates**: _[LocationFeedResponseCandidatesItem](\_responses_location_feed_response_.locationfeedresponsecandidatesitem.md)[]\_

_Defined in [responses/location.feed.response.ts:115](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/location.feed.response.ts#L115)_
