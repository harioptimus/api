> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/media.repository.list-reel-media-viewer.response"](../modules/_responses_media_repository_list_reel_media_viewer_response_.md) / [MediaRepositoryListReelMediaViewerResponseImage_versions2](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseimage_versions2.md) /

# Interface: MediaRepositoryListReelMediaViewerResponseImage_versions2

## Hierarchy

- **MediaRepositoryListReelMediaViewerResponseImage_versions2**

## Index

### Properties

- [candidates](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseimage_versions2.md#candidates)

## Properties

### candidates

• **candidates**: _[MediaRepositoryListReelMediaViewerResponseCandidatesItem](\_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponsecandidatesitem.md)[]\_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:67](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L67)_
