> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/music-trending.feed.response"](../modules/_responses_music_trending_feed_response_.md) / [MusicTrendingFeedResponseItemsItem](_responses_music_trending_feed_response_.musictrendingfeedresponseitemsitem.md) /

# Interface: MusicTrendingFeedResponseItemsItem

## Hierarchy

- **MusicTrendingFeedResponseItemsItem**

## Index

### Properties

- [track](_responses_music_trending_feed_response_.musictrendingfeedresponseitemsitem.md#track)

## Properties

### track

• **track**: _[MusicTrendingFeedResponseTrack](\_responses_music_trending_feed_response_.musictrendingfeedresponsetrack.md)\_

_Defined in [responses/music-trending.feed.response.ts:8](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/music-trending.feed.response.ts#L8)_
