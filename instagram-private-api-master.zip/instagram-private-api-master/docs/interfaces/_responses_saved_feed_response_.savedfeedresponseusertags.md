> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/saved.feed.response"](../modules/_responses_saved_feed_response_.md) / [SavedFeedResponseUsertags](_responses_saved_feed_response_.savedfeedresponseusertags.md) /

# Interface: SavedFeedResponseUsertags

## Hierarchy

- **SavedFeedResponseUsertags**

## Index

### Properties

- [in](_responses_saved_feed_response_.savedfeedresponseusertags.md#in)

## Properties

### in

• **in**: _[SavedFeedResponseInItem](\_responses_saved_feed_response_.savedfeedresponseinitem.md)[]\_

_Defined in [responses/saved.feed.response.ts:137](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/saved.feed.response.ts#L137)_
