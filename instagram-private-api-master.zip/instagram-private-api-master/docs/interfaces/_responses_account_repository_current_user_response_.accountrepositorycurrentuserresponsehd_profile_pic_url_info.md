> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/account.repository.current-user.response"](../modules/_responses_account_repository_current_user_response_.md) / [AccountRepositoryCurrentUserResponseHd_profile_pic_url_info](_responses_account_repository_current_user_response_.accountrepositorycurrentuserresponsehd_profile_pic_url_info.md) /

# Interface: AccountRepositoryCurrentUserResponseHd_profile_pic_url_info

## Hierarchy

- **AccountRepositoryCurrentUserResponseHd_profile_pic_url_info**

## Index

### Properties

- [height](_responses_account_repository_current_user_response_.accountrepositorycurrentuserresponsehd_profile_pic_url_info.md#height)
- [url](_responses_account_repository_current_user_response_.accountrepositorycurrentuserresponsehd_profile_pic_url_info.md#url)
- [width](_responses_account_repository_current_user_response_.accountrepositorycurrentuserresponsehd_profile_pic_url_info.md#width)

## Properties

### height

• **height**: _number_

_Defined in [responses/account.repository.current-user.response.ts:43](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/account.repository.current-user.response.ts#L43)_

---

### url

• **url**: _string_

_Defined in [responses/account.repository.current-user.response.ts:41](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/account.repository.current-user.response.ts#L41)_

---

### width

• **width**: _number_

_Defined in [responses/account.repository.current-user.response.ts:42](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/account.repository.current-user.response.ts#L42)_
