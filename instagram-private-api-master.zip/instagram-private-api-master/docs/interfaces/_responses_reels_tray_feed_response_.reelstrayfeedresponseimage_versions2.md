> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/reels-tray.feed.response"](../modules/_responses_reels_tray_feed_response_.md) / [ReelsTrayFeedResponseImage_versions2](_responses_reels_tray_feed_response_.reelstrayfeedresponseimage_versions2.md) /

# Interface: ReelsTrayFeedResponseImage_versions2

## Hierarchy

- **ReelsTrayFeedResponseImage_versions2**

## Index

### Properties

- [candidates](_responses_reels_tray_feed_response_.reelstrayfeedresponseimage_versions2.md#candidates)

## Properties

### candidates

• **candidates**: _[ReelsTrayFeedResponseCandidatesItem](\_responses_reels_tray_feed_response_.reelstrayfeedresponsecandidatesitem.md)[]\_

_Defined in [responses/reels-tray.feed.response.ts:97](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/reels-tray.feed.response.ts#L97)_
