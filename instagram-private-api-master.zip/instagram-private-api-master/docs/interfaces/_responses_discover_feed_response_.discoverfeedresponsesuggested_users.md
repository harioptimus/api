> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/discover.feed.response"](../modules/_responses_discover_feed_response_.md) / [DiscoverFeedResponseSuggested_users](_responses_discover_feed_response_.discoverfeedresponsesuggested_users.md) /

# Interface: DiscoverFeedResponseSuggested_users

## Hierarchy

- **DiscoverFeedResponseSuggested_users**

## Index

### Properties

- [suggestions](_responses_discover_feed_response_.discoverfeedresponsesuggested_users.md#suggestions)

## Properties

### suggestions

• **suggestions**: _[DiscoverFeedResponseSuggestionsItem](\_responses_discover_feed_response_.discoverfeedresponsesuggestionsitem.md)[]\_

_Defined in [responses/discover.feed.response.ts:12](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/discover.feed.response.ts#L12)_
