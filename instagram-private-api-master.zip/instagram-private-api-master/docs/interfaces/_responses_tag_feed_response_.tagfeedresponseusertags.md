> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/tag.feed.response"](../modules/_responses_tag_feed_response_.md) / [TagFeedResponseUsertags](_responses_tag_feed_response_.tagfeedresponseusertags.md) /

# Interface: TagFeedResponseUsertags

## Hierarchy

- **TagFeedResponseUsertags**

## Index

### Properties

- [in](_responses_tag_feed_response_.tagfeedresponseusertags.md#in)

## Properties

### in

• **in**: _[TagFeedResponseInItem](\_responses_tag_feed_response_.tagfeedresponseinitem.md)[]\_

_Defined in [responses/tag.feed.response.ts:117](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/tag.feed.response.ts#L117)_
