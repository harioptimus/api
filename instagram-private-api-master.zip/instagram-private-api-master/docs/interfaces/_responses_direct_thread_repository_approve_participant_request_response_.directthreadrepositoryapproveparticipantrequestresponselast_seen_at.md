> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/direct-thread.repository.approve-participant-request.response"](../modules/_responses_direct_thread_repository_approve_participant_request_response_.md) / [DirectThreadRepositoryApproveParticipantRequestResponseLast_seen_at](_responses_direct_thread_repository_approve_participant_request_response_.directthreadrepositoryapproveparticipantrequestresponselast_seen_at.md) /

# Interface: DirectThreadRepositoryApproveParticipantRequestResponseLast_seen_at

## Hierarchy

- **DirectThreadRepositoryApproveParticipantRequestResponseLast_seen_at**
