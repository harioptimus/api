> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/music.repository.genres.response"](../modules/_responses_music_repository_genres_response_.md) / [MusicRepositoryGenresResponseRootObject](_responses_music_repository_genres_response_.musicrepositorygenresresponserootobject.md) /

# Interface: MusicRepositoryGenresResponseRootObject

## Hierarchy

- **MusicRepositoryGenresResponseRootObject**

## Index

### Properties

- [items](_responses_music_repository_genres_response_.musicrepositorygenresresponserootobject.md#items)
- [status](_responses_music_repository_genres_response_.musicrepositorygenresresponserootobject.md#status)

## Properties

### items

• **items**: _[MusicRepositoryGenresResponseItemsItem](\_responses_music_repository_genres_response_.musicrepositorygenresresponseitemsitem.md)[]\_

_Defined in [responses/music.repository.genres.response.ts:2](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/music.repository.genres.response.ts#L2)_

---

### status

• **status**: _string_

_Defined in [responses/music.repository.genres.response.ts:3](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/music.repository.genres.response.ts#L3)_
