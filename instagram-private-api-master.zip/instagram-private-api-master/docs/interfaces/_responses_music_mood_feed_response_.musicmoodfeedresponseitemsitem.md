> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/music-mood.feed.response"](../modules/_responses_music_mood_feed_response_.md) / [MusicMoodFeedResponseItemsItem](_responses_music_mood_feed_response_.musicmoodfeedresponseitemsitem.md) /

# Interface: MusicMoodFeedResponseItemsItem

## Hierarchy

- **MusicMoodFeedResponseItemsItem**

## Index

### Properties

- [track](_responses_music_mood_feed_response_.musicmoodfeedresponseitemsitem.md#track)

## Properties

### track

• **track**: _[MusicMoodFeedResponseTrack](\_responses_music_mood_feed_response_.musicmoodfeedresponsetrack.md)\_

_Defined in [responses/music-mood.feed.response.ts:8](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/music-mood.feed.response.ts#L8)_
