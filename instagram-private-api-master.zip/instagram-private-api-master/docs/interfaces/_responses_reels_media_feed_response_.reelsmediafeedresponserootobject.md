> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/reels-media.feed.response"](../modules/_responses_reels_media_feed_response_.md) / [ReelsMediaFeedResponseRootObject](_responses_reels_media_feed_response_.reelsmediafeedresponserootobject.md) /

# Interface: ReelsMediaFeedResponseRootObject

## Hierarchy

- **ReelsMediaFeedResponseRootObject**

## Index

### Properties

- [reels](_responses_reels_media_feed_response_.reelsmediafeedresponserootobject.md#reels)
- [status](_responses_reels_media_feed_response_.reelsmediafeedresponserootobject.md#status)

## Properties

### reels

• **reels**: _[ReelsMediaFeedResponseReels](\_responses_reels_media_feed_response_.reelsmediafeedresponsereels.md)\_

_Defined in [responses/reels-media.feed.response.ts:2](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/reels-media.feed.response.ts#L2)_

---

### status

• **status**: _string_

_Defined in [responses/reels-media.feed.response.ts:3](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/reels-media.feed.response.ts#L3)_
