> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/account.repository.current-user.response"](../modules/_responses_account_repository_current_user_response_.md) / [AccountRepositoryCurrentUserResponseBiography_with_entities](_responses_account_repository_current_user_response_.accountrepositorycurrentuserresponsebiography_with_entities.md) /

# Interface: AccountRepositoryCurrentUserResponseBiography_with_entities

## Hierarchy

- **AccountRepositoryCurrentUserResponseBiography_with_entities**

## Index

### Properties

- [entities](_responses_account_repository_current_user_response_.accountrepositorycurrentuserresponsebiography_with_entities.md#entities)
- [raw_text](_responses_account_repository_current_user_response_.accountrepositorycurrentuserresponsebiography_with_entities.md#raw_text)

## Properties

### entities

• **entities**: _any[]_

_Defined in [responses/account.repository.current-user.response.ts:33](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/account.repository.current-user.response.ts#L33)_

---

### raw_text

• **raw_text**: _string_

_Defined in [responses/account.repository.current-user.response.ts:32](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/account.repository.current-user.response.ts#L32)_
