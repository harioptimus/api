> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/account.repository.login.response"](../modules/_responses_account_repository_login_response_.md) / [AccountRepositoryLoginResponseNametag](_responses_account_repository_login_response_.accountrepositoryloginresponsenametag.md) /

# Interface: AccountRepositoryLoginResponseNametag

## Hierarchy

- **AccountRepositoryLoginResponseNametag**

## Index

### Properties

- [emoji](_responses_account_repository_login_response_.accountrepositoryloginresponsenametag.md#emoji)
- [gradient](_responses_account_repository_login_response_.accountrepositoryloginresponsenametag.md#gradient)
- [mode](_responses_account_repository_login_response_.accountrepositoryloginresponsenametag.md#mode)
- [selfie_sticker](_responses_account_repository_login_response_.accountrepositoryloginresponsenametag.md#selfie_sticker)

## Properties

### emoji

• **emoji**: _string_

_Defined in [responses/account.repository.login.response.ts:32](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/account.repository.login.response.ts#L32)_

---

### gradient

• **gradient**: _string_

_Defined in [responses/account.repository.login.response.ts:31](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/account.repository.login.response.ts#L31)_

---

### mode

• **mode**: _number_

_Defined in [responses/account.repository.login.response.ts:30](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/account.repository.login.response.ts#L30)_

---

### selfie_sticker

• **selfie_sticker**: _string_

_Defined in [responses/account.repository.login.response.ts:33](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/account.repository.login.response.ts#L33)_
