> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/media-comments.feed.response"](../modules/_responses_media_comments_feed_response_.md) / [MediaCommentsFeedResponseOtherPreviewUsersItem](_responses_media_comments_feed_response_.mediacommentsfeedresponseotherpreviewusersitem.md) /

# Interface: MediaCommentsFeedResponseOtherPreviewUsersItem

## Hierarchy

- **MediaCommentsFeedResponseOtherPreviewUsersItem**

## Index

### Properties

- [id](_responses_media_comments_feed_response_.mediacommentsfeedresponseotherpreviewusersitem.md#id)
- [profile_pic_url](_responses_media_comments_feed_response_.mediacommentsfeedresponseotherpreviewusersitem.md#profile_pic_url)

## Properties

### id

• **id**: _number_

_Defined in [responses/media-comments.feed.response.ts:74](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media-comments.feed.response.ts#L74)_

---

### profile_pic_url

• **profile_pic_url**: _string_

_Defined in [responses/media-comments.feed.response.ts:75](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media-comments.feed.response.ts#L75)_
