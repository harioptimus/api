> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/tag.feed.response"](../modules/_responses_tag_feed_response_.md) / [TagFeedResponseImage_versions2](_responses_tag_feed_response_.tagfeedresponseimage_versions2.md) /

# Interface: TagFeedResponseImage_versions2

## Hierarchy

- **TagFeedResponseImage_versions2**

## Index

### Properties

- [candidates](_responses_tag_feed_response_.tagfeedresponseimage_versions2.md#candidates)

## Properties

### candidates

• **candidates**: _[TagFeedResponseCandidatesItem](\_responses_tag_feed_response_.tagfeedresponsecandidatesitem.md)[]\_

_Defined in [responses/tag.feed.response.ts:77](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/tag.feed.response.ts#L77)_
