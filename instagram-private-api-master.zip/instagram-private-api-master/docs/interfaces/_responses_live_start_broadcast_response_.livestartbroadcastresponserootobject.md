> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/live.start-broadcast.response"](../modules/_responses_live_start_broadcast_response_.md) / [LiveStartBroadcastResponseRootObject](_responses_live_start_broadcast_response_.livestartbroadcastresponserootobject.md) /

# Interface: LiveStartBroadcastResponseRootObject

## Hierarchy

- **LiveStartBroadcastResponseRootObject**

## Index

### Properties

- [media_id](_responses_live_start_broadcast_response_.livestartbroadcastresponserootobject.md#media_id)
- [status](_responses_live_start_broadcast_response_.livestartbroadcastresponserootobject.md#status)

## Properties

### media_id

• **media_id**: _string_

_Defined in [responses/live.start-broadcast.response.ts:2](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/live.start-broadcast.response.ts#L2)_

---

### status

• **status**: _string_

_Defined in [responses/live.start-broadcast.response.ts:3](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/live.start-broadcast.response.ts#L3)_
