> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/media-comments.feed.response"](../modules/_responses_media_comments_feed_response_.md) / [MediaCommentsFeedResponseQuickResponseEmojisItem](_responses_media_comments_feed_response_.mediacommentsfeedresponsequickresponseemojisitem.md) /

# Interface: MediaCommentsFeedResponseQuickResponseEmojisItem

## Hierarchy

- **MediaCommentsFeedResponseQuickResponseEmojisItem**

## Index

### Properties

- [unicode](_responses_media_comments_feed_response_.mediacommentsfeedresponsequickresponseemojisitem.md#unicode)

## Properties

### unicode

• **unicode**: _string_

_Defined in [responses/media-comments.feed.response.ts:93](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media-comments.feed.response.ts#L93)_
