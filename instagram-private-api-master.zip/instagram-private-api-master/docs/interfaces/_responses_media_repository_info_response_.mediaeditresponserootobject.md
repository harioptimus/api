> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/media.repository.info.response"](../modules/_responses_media_repository_info_response_.md) / [MediaEditResponseRootObject](_responses_media_repository_info_response_.mediaeditresponserootobject.md) /

# Interface: MediaEditResponseRootObject

## Hierarchy

- **MediaEditResponseRootObject**

## Index

### Properties

- [media](_responses_media_repository_info_response_.mediaeditresponserootobject.md#media)
- [status](_responses_media_repository_info_response_.mediaeditresponserootobject.md#status)

## Properties

### media

• **media**: _[MediaInfoResponseItemsItem](\_responses_media_repository_info_response_.mediainforesponseitemsitem.md)\_

_Defined in [responses/media.repository.info.response.ts:83](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.info.response.ts#L83)_

---

### status

• **status**: _string_

_Defined in [responses/media.repository.info.response.ts:84](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.info.response.ts#L84)_
