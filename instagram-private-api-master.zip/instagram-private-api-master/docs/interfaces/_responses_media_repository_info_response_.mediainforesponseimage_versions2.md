> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/media.repository.info.response"](../modules/_responses_media_repository_info_response_.md) / [MediaInfoResponseImage_versions2](_responses_media_repository_info_response_.mediainforesponseimage_versions2.md) /

# Interface: MediaInfoResponseImage_versions2

## Hierarchy

- **MediaInfoResponseImage_versions2**

## Index

### Properties

- [candidates](_responses_media_repository_info_response_.mediainforesponseimage_versions2.md#candidates)

## Properties

### candidates

• **candidates**: _[MediaInfoResponseCandidatesItem](\_responses_media_repository_info_response_.mediainforesponsecandidatesitem.md)[]\_

_Defined in [responses/media.repository.info.response.ts:41](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.info.response.ts#L41)_
