> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/account.repository.current-user.response"](../modules/_responses_account_repository_current_user_response_.md) / [AccountRepositoryCurrentUserResponseHdProfilePicVersionsItem](_responses_account_repository_current_user_response_.accountrepositorycurrentuserresponsehdprofilepicversionsitem.md) /

# Interface: AccountRepositoryCurrentUserResponseHdProfilePicVersionsItem

## Hierarchy

- **AccountRepositoryCurrentUserResponseHdProfilePicVersionsItem**

## Index

### Properties

- [height](_responses_account_repository_current_user_response_.accountrepositorycurrentuserresponsehdprofilepicversionsitem.md#height)
- [url](_responses_account_repository_current_user_response_.accountrepositorycurrentuserresponsehdprofilepicversionsitem.md#url)
- [width](_responses_account_repository_current_user_response_.accountrepositorycurrentuserresponsehdprofilepicversionsitem.md#width)

## Properties

### height

• **height**: _number_

_Defined in [responses/account.repository.current-user.response.ts:37](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/account.repository.current-user.response.ts#L37)_

---

### url

• **url**: _string_

_Defined in [responses/account.repository.current-user.response.ts:38](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/account.repository.current-user.response.ts#L38)_

---

### width

• **width**: _number_

_Defined in [responses/account.repository.current-user.response.ts:36](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/account.repository.current-user.response.ts#L36)_
