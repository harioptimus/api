> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/reels-media.feed.response"](../modules/_responses_reels_media_feed_response_.md) / [ReelsMediaFeedResponseStoryCtaItem](_responses_reels_media_feed_response_.reelsmediafeedresponsestoryctaitem.md) /

# Interface: ReelsMediaFeedResponseStoryCtaItem

## Hierarchy

- **ReelsMediaFeedResponseStoryCtaItem**

## Index

### Properties

- [links](_responses_reels_media_feed_response_.reelsmediafeedresponsestoryctaitem.md#links)

## Properties

### links

• **links**: _[ReelsMediaFeedResponseLinksItem](\_responses_reels_media_feed_response_.reelsmediafeedresponselinksitem.md)[]\_

_Defined in [responses/reels-media.feed.response.ts:104](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/reels-media.feed.response.ts#L104)_
