> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/user.repository.info.response"](../modules/_responses_user_repository_info_response_.md) / [UserRepositoryInfoResponseHdProfilePicVersionsItem](_responses_user_repository_info_response_.userrepositoryinforesponsehdprofilepicversionsitem.md) /

# Interface: UserRepositoryInfoResponseHdProfilePicVersionsItem

## Hierarchy

- **UserRepositoryInfoResponseHdProfilePicVersionsItem**

## Index

### Properties

- [height](_responses_user_repository_info_response_.userrepositoryinforesponsehdprofilepicversionsitem.md#height)
- [url](_responses_user_repository_info_response_.userrepositoryinforesponsehdprofilepicversionsitem.md#url)
- [width](_responses_user_repository_info_response_.userrepositoryinforesponsehdprofilepicversionsitem.md#width)

## Properties

### height

• **height**: _number_

_Defined in [responses/user.repository.info.response.ts:79](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/user.repository.info.response.ts#L79)_

---

### url

• **url**: _string_

_Defined in [responses/user.repository.info.response.ts:80](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/user.repository.info.response.ts#L80)_

---

### width

• **width**: _number_

_Defined in [responses/user.repository.info.response.ts:78](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/user.repository.info.response.ts#L78)_
