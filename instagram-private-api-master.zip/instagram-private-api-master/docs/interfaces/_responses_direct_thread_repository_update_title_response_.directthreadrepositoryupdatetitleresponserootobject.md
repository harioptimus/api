> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/direct-thread.repository.update-title.response"](../modules/_responses_direct_thread_repository_update_title_response_.md) / [DirectThreadRepositoryUpdateTitleResponseRootObject](_responses_direct_thread_repository_update_title_response_.directthreadrepositoryupdatetitleresponserootobject.md) /

# Interface: DirectThreadRepositoryUpdateTitleResponseRootObject

## Hierarchy

- **DirectThreadRepositoryUpdateTitleResponseRootObject**

## Index

### Properties

- [status](_responses_direct_thread_repository_update_title_response_.directthreadrepositoryupdatetitleresponserootobject.md#status)
- [thread](_responses_direct_thread_repository_update_title_response_.directthreadrepositoryupdatetitleresponserootobject.md#thread)

## Properties

### status

• **status**: _string_

_Defined in [responses/direct-thread.repository.update-title.response.ts:3](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.update-title.response.ts#L3)_

---

### thread

• **thread**: _[DirectThreadRepositoryUpdateTitleResponseThread](\_responses_direct_thread_repository_update_title_response_.directthreadrepositoryupdatetitleresponsethread.md)\_

_Defined in [responses/direct-thread.repository.update-title.response.ts:2](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.update-title.response.ts#L2)_
