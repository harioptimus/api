> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/direct-thread.repository.approve-participant-request.response"](../modules/_responses_direct_thread_repository_approve_participant_request_response_.md) / [DirectThreadRepositoryApproveParticipantRequestResponseRootObject](_responses_direct_thread_repository_approve_participant_request_response_.directthreadrepositoryapproveparticipantrequestresponserootobject.md) /

# Interface: DirectThreadRepositoryApproveParticipantRequestResponseRootObject

## Hierarchy

- **DirectThreadRepositoryApproveParticipantRequestResponseRootObject**

## Index

### Properties

- [status](_responses_direct_thread_repository_approve_participant_request_response_.directthreadrepositoryapproveparticipantrequestresponserootobject.md#status)
- [thread](_responses_direct_thread_repository_approve_participant_request_response_.directthreadrepositoryapproveparticipantrequestresponserootobject.md#thread)

## Properties

### status

• **status**: _string_

_Defined in [responses/direct-thread.repository.approve-participant-request.response.ts:3](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.approve-participant-request.response.ts#L3)_

---

### thread

• **thread**: _[DirectThreadRepositoryApproveParticipantRequestResponseThread](\_responses_direct_thread_repository_approve_participant_request_response_.directthreadrepositoryapproveparticipantrequestresponsethread.md)\_

_Defined in [responses/direct-thread.repository.approve-participant-request.response.ts:2](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.approve-participant-request.response.ts#L2)_
