> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/user.repository.info.response"](../modules/_responses_user_repository_info_response_.md) / [UserRepositoryInfoResponseNametag](_responses_user_repository_info_response_.userrepositoryinforesponsenametag.md) /

# Interface: UserRepositoryInfoResponseNametag

## Hierarchy

- **UserRepositoryInfoResponseNametag**

## Index

### Properties

- [emoji](_responses_user_repository_info_response_.userrepositoryinforesponsenametag.md#emoji)
- [gradient](_responses_user_repository_info_response_.userrepositoryinforesponsenametag.md#gradient)
- [mode](_responses_user_repository_info_response_.userrepositoryinforesponsenametag.md#mode)
- [selfie_sticker](_responses_user_repository_info_response_.userrepositoryinforesponsenametag.md#selfie_sticker)

## Properties

### emoji

• **emoji**: _string_

_Defined in [responses/user.repository.info.response.ts:90](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/user.repository.info.response.ts#L90)_

---

### gradient

• **gradient**: _string_

_Defined in [responses/user.repository.info.response.ts:89](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/user.repository.info.response.ts#L89)_

---

### mode

• **mode**: _number_

_Defined in [responses/user.repository.info.response.ts:88](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/user.repository.info.response.ts#L88)_

---

### selfie_sticker

• **selfie_sticker**: _string_

_Defined in [responses/user.repository.info.response.ts:91](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/user.repository.info.response.ts#L91)_
