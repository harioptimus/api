> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/usertags.feed.response"](../modules/_responses_usertags_feed_response_.md) / [UsertagsFeedResponseImage_versions2](_responses_usertags_feed_response_.usertagsfeedresponseimage_versions2.md) /

# Interface: UsertagsFeedResponseImage_versions2

## Hierarchy

- **UsertagsFeedResponseImage_versions2**

## Index

### Properties

- [candidates](_responses_usertags_feed_response_.usertagsfeedresponseimage_versions2.md#candidates)

## Properties

### candidates

• **candidates**: _[UsertagsFeedResponseCandidatesItem](\_responses_usertags_feed_response_.usertagsfeedresponsecandidatesitem.md)[]\_

_Defined in [responses/usertags.feed.response.ts:49](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/usertags.feed.response.ts#L49)_
