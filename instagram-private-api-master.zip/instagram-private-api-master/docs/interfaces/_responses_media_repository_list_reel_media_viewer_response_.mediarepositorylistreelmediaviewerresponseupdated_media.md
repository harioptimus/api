> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/media.repository.list-reel-media-viewer.response"](../modules/_responses_media_repository_list_reel_media_viewer_response_.md) / [MediaRepositoryListReelMediaViewerResponseUpdated_media](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md) /

# Interface: MediaRepositoryListReelMediaViewerResponseUpdated_media

## Hierarchy

- **MediaRepositoryListReelMediaViewerResponseUpdated_media**

## Index

### Properties

- [can_reply](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#can_reply)
- [can_reshare](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#can_reshare)
- [can_viewer_save](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#can_viewer_save)
- [caption](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#caption)
- [caption_is_edited](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#caption_is_edited)
- [caption_position](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#caption_position)
- [client_cache_key](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#client_cache_key)
- [code](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#code)
- [device_timestamp](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#device_timestamp)
- [expiring_at](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#expiring_at)
- [fb_user_tags](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#fb_user_tags)
- [filter_type](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#filter_type)
- [has_shared_to_fb](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#has_shared_to_fb)
- [id](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#id)
- [image_versions2](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#image_versions2)
- [is_pride_media](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#is_pride_media)
- [is_reel_media](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#is_reel_media)
- [media_type](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#media_type)
- [multi_author_reel_names](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#multi_author_reel_names)
- [organic_tracking_token](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#organic_tracking_token)
- [original_height](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#original_height)
- [original_width](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#original_width)
- [photo_of_you](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#photo_of_you)
- [pk](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#pk)
- [show_one_tap_fb_share_tooltip](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#show_one_tap_fb_share_tooltip)
- [story_chat_request_infos](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#story_chat_request_infos)
- [story_chats](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#story_chats)
- [story_is_saved_to_archive](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#story_is_saved_to_archive)
- [supports_reel_reactions](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#supports_reel_reactions)
- [taken_at](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#taken_at)
- [timezone_offset](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#timezone_offset)
- [total_viewer_count](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#total_viewer_count)
- [user](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#user)
- [viewer_count](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#viewer_count)
- [viewer_cursor](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#viewer_cursor)
- [viewers](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseupdated_media.md#viewers)

## Properties

### can_reply

• **can_reply**: _boolean_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:52](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L52)_

---

### can_reshare

• **can_reshare**: _boolean_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:51](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L51)_

---

### can_viewer_save

• **can_viewer_save**: _boolean_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:48](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L48)_

---

### caption

• **caption**: _null_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:46](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L46)_

---

### caption_is_edited

• **caption_is_edited**: _boolean_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:41](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L41)_

---

### caption_position

• **caption_position**: _number_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:42](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L42)_

---

### client_cache_key

• **client_cache_key**: _string_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:35](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L35)_

---

### code

• **code**: _string_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:34](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L34)_

---

### device_timestamp

• **device_timestamp**: _number_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:32](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L32)_

---

### expiring_at

• **expiring_at**: _number_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:50](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L50)_

---

### fb_user_tags

• **fb_user_tags**: _[MediaRepositoryListReelMediaViewerResponseFb_user_tags](\_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponsefb*user_tags.md)*

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:47](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L47)_

---

### filter_type

• **filter_type**: _number_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:36](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L36)_

---

### has_shared_to_fb

• **has_shared_to_fb**: _number_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:64](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L64)_

---

### id

• **id**: _string_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:31](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L31)_

---

### image_versions2

• **image_versions2**: _[MediaRepositoryListReelMediaViewerResponseImage_versions2](\_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseimage*versions2.md)*

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:37](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L37)_

---

### is_pride_media

• **is_pride_media**: _boolean_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:53](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L53)_

---

### is_reel_media

• **is_reel_media**: _boolean_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:43](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L43)_

---

### media_type

• **media_type**: _number_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:33](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L33)_

---

### multi_author_reel_names

• **multi_author_reel_names**: _any[]_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:61](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L61)_

---

### organic_tracking_token

• **organic_tracking_token**: _string_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:49](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L49)_

---

### original_height

• **original_height**: _number_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:39](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L39)_

---

### original_width

• **original_width**: _number_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:38](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L38)_

---

### photo_of_you

• **photo_of_you**: _boolean_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:45](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L45)_

---

### pk

• **pk**: _string_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:30](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L30)_

---

### show_one_tap_fb_share_tooltip

• **show_one_tap_fb_share_tooltip**: _boolean_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:63](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L63)_

---

### story_chat_request_infos

• **story_chat_request_infos**: _[MediaRepositoryListReelMediaViewerResponseStoryChatRequestInfosItem](\_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponsestorychatrequestinfositem.md)[]\_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:56](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L56)_

---

### story_chats

• **story_chats**: _[MediaRepositoryListReelMediaViewerResponseStoryChatsItem](\_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponsestorychatsitem.md)[]\_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:55](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L55)_

---

### story_is_saved_to_archive

• **story_is_saved_to_archive**: _boolean_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:54](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L54)_

---

### supports_reel_reactions

• **supports_reel_reactions**: _boolean_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:62](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L62)_

---

### taken_at

• **taken_at**: _number_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:29](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L29)_

---

### timezone_offset

• **timezone_offset**: _number_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:44](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L44)_

---

### total_viewer_count

• **total_viewer_count**: _number_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:60](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L60)_

---

### user

• **user**: _[MediaRepositoryListReelMediaViewerResponseUser](\_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseuser.md)\_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:40](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L40)_

---

### viewer_count

• **viewer_count**: _number_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:58](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L58)_

---

### viewer_cursor

• **viewer_cursor**: _null_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:59](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L59)_

---

### viewers

• **viewers**: _[MediaRepositoryListReelMediaViewerResponseViewersItem](\_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponseviewersitem.md)[]\_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:57](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L57)_
