> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/music.repository.moods.response"](../modules/_responses_music_repository_moods_response_.md) / [MusicRepositoryMoodsResponseItemsItem](_responses_music_repository_moods_response_.musicrepositorymoodsresponseitemsitem.md) /

# Interface: MusicRepositoryMoodsResponseItemsItem

## Hierarchy

- **MusicRepositoryMoodsResponseItemsItem**

## Index

### Properties

- [mood](_responses_music_repository_moods_response_.musicrepositorymoodsresponseitemsitem.md#mood)

## Properties

### mood

• **mood**: _[MusicRepositoryMoodsResponseMood](\_responses_music_repository_moods_response_.musicrepositorymoodsresponsemood.md)\_

_Defined in [responses/music.repository.moods.response.ts:6](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/music.repository.moods.response.ts#L6)_
