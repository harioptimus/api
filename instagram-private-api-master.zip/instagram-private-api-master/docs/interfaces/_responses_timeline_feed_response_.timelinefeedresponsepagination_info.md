> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/timeline.feed.response"](../modules/_responses_timeline_feed_response_.md) / [TimelineFeedResponsePagination_info](_responses_timeline_feed_response_.timelinefeedresponsepagination_info.md) /

# Interface: TimelineFeedResponsePagination_info

## Hierarchy

- **TimelineFeedResponsePagination_info**

## Index

### Properties

- [group_id](_responses_timeline_feed_response_.timelinefeedresponsepagination_info.md#group_id)
- [source](_responses_timeline_feed_response_.timelinefeedresponsepagination_info.md#source)

## Properties

### group_id

• **group_id**: _null_

_Defined in [responses/timeline.feed.response.ts:284](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/timeline.feed.response.ts#L284)_

---

### source

• **source**: _null_

_Defined in [responses/timeline.feed.response.ts:283](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/timeline.feed.response.ts#L283)_
