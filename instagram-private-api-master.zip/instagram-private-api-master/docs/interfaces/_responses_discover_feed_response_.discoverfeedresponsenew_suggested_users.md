> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/discover.feed.response"](../modules/_responses_discover_feed_response_.md) / [DiscoverFeedResponseNew_suggested_users](_responses_discover_feed_response_.discoverfeedresponsenew_suggested_users.md) /

# Interface: DiscoverFeedResponseNew_suggested_users

## Hierarchy

- **DiscoverFeedResponseNew_suggested_users**

## Index

### Properties

- [suggestions](_responses_discover_feed_response_.discoverfeedresponsenew_suggested_users.md#suggestions)

## Properties

### suggestions

• **suggestions**: _any[]_

_Defined in [responses/discover.feed.response.ts:40](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/discover.feed.response.ts#L40)_
