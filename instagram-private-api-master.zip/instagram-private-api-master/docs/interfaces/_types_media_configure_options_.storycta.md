> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/media.configure.options"](../modules/_types_media_configure_options_.md) / [StoryCta](_types_media_configure_options_.storycta.md) /

# Interface: StoryCta

## Hierarchy

- **StoryCta**

## Index

### Properties

- [links](_types_media_configure_options_.storycta.md#links)

## Properties

### links

• **links**: _[object]_

_Defined in [types/media.configure.options.ts:116](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/types/media.configure.options.ts#L116)_
