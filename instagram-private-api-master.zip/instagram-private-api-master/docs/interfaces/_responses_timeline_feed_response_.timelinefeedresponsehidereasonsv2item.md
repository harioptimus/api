> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/timeline.feed.response"](../modules/_responses_timeline_feed_response_.md) / [TimelineFeedResponseHideReasonsV2Item](_responses_timeline_feed_response_.timelinefeedresponsehidereasonsv2item.md) /

# Interface: TimelineFeedResponseHideReasonsV2Item

## Hierarchy

- **TimelineFeedResponseHideReasonsV2Item**

## Index

### Properties

- [reason](_responses_timeline_feed_response_.timelinefeedresponsehidereasonsv2item.md#reason)
- [text](_responses_timeline_feed_response_.timelinefeedresponsehidereasonsv2item.md#text)

## Properties

### reason

• **reason**: _string | null_

_Defined in [responses/timeline.feed.response.ts:173](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/timeline.feed.response.ts#L173)_

---

### text

• **text**: _string_

_Defined in [responses/timeline.feed.response.ts:172](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/timeline.feed.response.ts#L172)_
