> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/direct-thread.feed.response"](../modules/_responses_direct_thread_feed_response_.md) / [DirectThreadFeedResponse300687565](_responses_direct_thread_feed_response_.directthreadfeedresponse300687565.md) /

# Interface: DirectThreadFeedResponse300687565

## Hierarchy

- **DirectThreadFeedResponse300687565**

## Index

### Properties

- [item_id](_responses_direct_thread_feed_response_.directthreadfeedresponse300687565.md#item_id)
- [timestamp](_responses_direct_thread_feed_response_.directthreadfeedresponse300687565.md#timestamp)

## Properties

### item_id

• **item_id**: _string_

_Defined in [responses/direct-thread.feed.response.ts:62](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.feed.response.ts#L62)_

---

### timestamp

• **timestamp**: _string_

_Defined in [responses/direct-thread.feed.response.ts:61](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.feed.response.ts#L61)_
