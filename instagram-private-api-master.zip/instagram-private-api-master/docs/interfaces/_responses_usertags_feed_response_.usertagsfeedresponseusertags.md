> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/usertags.feed.response"](../modules/_responses_usertags_feed_response_.md) / [UsertagsFeedResponseUsertags](_responses_usertags_feed_response_.usertagsfeedresponseusertags.md) /

# Interface: UsertagsFeedResponseUsertags

## Hierarchy

- **UsertagsFeedResponseUsertags**

## Index

### Properties

- [in](_responses_usertags_feed_response_.usertagsfeedresponseusertags.md#in)

## Properties

### in

• **in**: _[UsertagsFeedResponseInItem](\_responses_usertags_feed_response_.usertagsfeedresponseinitem.md)[]\_

_Defined in [responses/usertags.feed.response.ts:96](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/usertags.feed.response.ts#L96)_
