> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/music.repository.genres.response"](../modules/_responses_music_repository_genres_response_.md) / [MusicRepositoryGenresResponseItemsItem](_responses_music_repository_genres_response_.musicrepositorygenresresponseitemsitem.md) /

# Interface: MusicRepositoryGenresResponseItemsItem

## Hierarchy

- **MusicRepositoryGenresResponseItemsItem**

## Index

### Properties

- [genre](_responses_music_repository_genres_response_.musicrepositorygenresresponseitemsitem.md#genre)

## Properties

### genre

• **genre**: _[MusicRepositoryGenresResponseGenre](\_responses_music_repository_genres_response_.musicrepositorygenresresponsegenre.md)\_

_Defined in [responses/music.repository.genres.response.ts:6](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/music.repository.genres.response.ts#L6)_
