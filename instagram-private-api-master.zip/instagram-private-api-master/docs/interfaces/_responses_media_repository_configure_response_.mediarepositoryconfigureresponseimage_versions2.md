> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/media.repository.configure.response"](../modules/_responses_media_repository_configure_response_.md) / [MediaRepositoryConfigureResponseImage_versions2](_responses_media_repository_configure_response_.mediarepositoryconfigureresponseimage_versions2.md) /

# Interface: MediaRepositoryConfigureResponseImage_versions2

## Hierarchy

- **MediaRepositoryConfigureResponseImage_versions2**

## Index

### Properties

- [candidates](_responses_media_repository_configure_response_.mediarepositoryconfigureresponseimage_versions2.md#candidates)

## Properties

### candidates

• **candidates**: _[MediaRepositoryConfigureResponseCandidatesItem](\_responses_media_repository_configure_response_.mediarepositoryconfigureresponsecandidatesitem.md)[]\_

_Defined in [responses/media.repository.configure.response.ts:37](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.configure.response.ts#L37)_
