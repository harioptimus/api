> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/direct-thread.repository.update-title.response"](../modules/_responses_direct_thread_repository_update_title_response_.md) / [DirectThreadRepositoryUpdateTitleResponseBoldItem](_responses_direct_thread_repository_update_title_response_.directthreadrepositoryupdatetitleresponsebolditem.md) /

# Interface: DirectThreadRepositoryUpdateTitleResponseBoldItem

## Hierarchy

- **DirectThreadRepositoryUpdateTitleResponseBoldItem**

## Index

### Properties

- [end](_responses_direct_thread_repository_update_title_response_.directthreadrepositoryupdatetitleresponsebolditem.md#end)
- [start](_responses_direct_thread_repository_update_title_response_.directthreadrepositoryupdatetitleresponsebolditem.md#start)

## Properties

### end

• **end**: _number_

_Defined in [responses/direct-thread.repository.update-title.response.ts:89](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.update-title.response.ts#L89)_

---

### start

• **start**: _number_

_Defined in [responses/direct-thread.repository.update-title.response.ts:88](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.update-title.response.ts#L88)_
