> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/direct-thread.repository.add-user.response"](../modules/_responses_direct_thread_repository_add_user_response_.md) / [DirectThreadRepositoryAddUserResponseTextAttributesItem](_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponsetextattributesitem.md) /

# Interface: DirectThreadRepositoryAddUserResponseTextAttributesItem

## Hierarchy

- **DirectThreadRepositoryAddUserResponseTextAttributesItem**

## Index

### Properties

- [bold](_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponsetextattributesitem.md#bold)
- [color](_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponsetextattributesitem.md#color)
- [end](_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponsetextattributesitem.md#end)
- [intent](_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponsetextattributesitem.md#intent)
- [start](_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponsetextattributesitem.md#start)

## Properties

### bold

• **bold**: _number_

_Defined in [responses/direct-thread.repository.add-user.response.ts:101](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.add-user.response.ts#L101)_

---

### color

• **color**: _string_

_Defined in [responses/direct-thread.repository.add-user.response.ts:102](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.add-user.response.ts#L102)_

---

### end

• **end**: _number_

_Defined in [responses/direct-thread.repository.add-user.response.ts:100](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.add-user.response.ts#L100)_

---

### intent

• **intent**: _string_

_Defined in [responses/direct-thread.repository.add-user.response.ts:103](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.add-user.response.ts#L103)_

---

### start

• **start**: _number_

_Defined in [responses/direct-thread.repository.add-user.response.ts:99](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.add-user.response.ts#L99)_
