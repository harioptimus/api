> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/news.feed.response"](../modules/_responses_news_feed_response_.md) / [NewsFeedResponseCounts](_responses_news_feed_response_.newsfeedresponsecounts.md) /

# Interface: NewsFeedResponseCounts

## Hierarchy

- **NewsFeedResponseCounts**
