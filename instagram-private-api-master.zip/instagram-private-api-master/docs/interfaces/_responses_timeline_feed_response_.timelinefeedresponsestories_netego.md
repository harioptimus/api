> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/timeline.feed.response"](../modules/_responses_timeline_feed_response_.md) / [TimelineFeedResponseStories_netego](_responses_timeline_feed_response_.timelinefeedresponsestories_netego.md) /

# Interface: TimelineFeedResponseStories_netego

## Hierarchy

- **TimelineFeedResponseStories_netego**

## Index

### Properties

- [hide_unit_if_seen](_responses_timeline_feed_response_.timelinefeedresponsestories_netego.md#hide_unit_if_seen)
- [id](_responses_timeline_feed_response_.timelinefeedresponsestories_netego.md#id)
- [tracking_token](_responses_timeline_feed_response_.timelinefeedresponsestories_netego.md#tracking_token)

## Properties

### hide_unit_if_seen

• **hide_unit_if_seen**: _string_

_Defined in [responses/timeline.feed.response.ts:279](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/timeline.feed.response.ts#L279)_

---

### id

• **id**: _number_

_Defined in [responses/timeline.feed.response.ts:280](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/timeline.feed.response.ts#L280)_

---

### tracking_token

• **tracking_token**: _string_

_Defined in [responses/timeline.feed.response.ts:278](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/timeline.feed.response.ts#L278)_
