> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/friendship.repository.change.response"](../modules/_responses_friendship_repository_change_response_.md) / [FriendshipRepositoryChangeResponseRootObject](_responses_friendship_repository_change_response_.friendshiprepositorychangeresponserootobject.md) /

# Interface: FriendshipRepositoryChangeResponseRootObject

## Hierarchy

- **FriendshipRepositoryChangeResponseRootObject**

## Index

### Properties

- [friendship_status](_responses_friendship_repository_change_response_.friendshiprepositorychangeresponserootobject.md#friendship_status)
- [status](_responses_friendship_repository_change_response_.friendshiprepositorychangeresponserootobject.md#status)

## Properties

### friendship_status

• **friendship_status**: _[FriendshipRepositoryChangeResponseFriendship_status](\_responses_friendship_repository_change_response_.friendshiprepositorychangeresponsefriendship*status.md)*

_Defined in [responses/friendship.repository.change.response.ts:2](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/friendship.repository.change.response.ts#L2)_

---

### status

• **status**: _string_

_Defined in [responses/friendship.repository.change.response.ts:3](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/friendship.repository.change.response.ts#L3)_
