> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/location.feed.response"](../modules/_responses_location_feed_response_.md) / [LocationFeedResponseUsertags](_responses_location_feed_response_.locationfeedresponseusertags.md) /

# Interface: LocationFeedResponseUsertags

## Hierarchy

- **LocationFeedResponseUsertags**

## Index

### Properties

- [in](_responses_location_feed_response_.locationfeedresponseusertags.md#in)

## Properties

### in

• **in**: _[LocationFeedResponseInItem](\_responses_location_feed_response_.locationfeedresponseinitem.md)[]\_

_Defined in [responses/location.feed.response.ts:155](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/location.feed.response.ts#L155)_
