> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/music-search.feed.response"](../modules/_responses_music_search_feed_response_.md) / [MusicSearchFeedResponseItemsItem](_responses_music_search_feed_response_.musicsearchfeedresponseitemsitem.md) /

# Interface: MusicSearchFeedResponseItemsItem

## Hierarchy

- **MusicSearchFeedResponseItemsItem**

## Index

### Properties

- [track](_responses_music_search_feed_response_.musicsearchfeedresponseitemsitem.md#track)

## Properties

### track

• **track**: _[MusicSearchFeedResponseTrack](\_responses_music_search_feed_response_.musicsearchfeedresponsetrack.md)\_

_Defined in [responses/music-search.feed.response.ts:8](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/music-search.feed.response.ts#L8)_
