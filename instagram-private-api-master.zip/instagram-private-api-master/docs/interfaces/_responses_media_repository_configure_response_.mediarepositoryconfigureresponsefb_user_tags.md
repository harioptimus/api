> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/media.repository.configure.response"](../modules/_responses_media_repository_configure_response_.md) / [MediaRepositoryConfigureResponseFb_user_tags](_responses_media_repository_configure_response_.mediarepositoryconfigureresponsefb_user_tags.md) /

# Interface: MediaRepositoryConfigureResponseFb_user_tags

## Hierarchy

- **MediaRepositoryConfigureResponseFb_user_tags**

## Index

### Properties

- [in](_responses_media_repository_configure_response_.mediarepositoryconfigureresponsefb_user_tags.md#in)

## Properties

### in

• **in**: _any[]_

_Defined in [responses/media.repository.configure.response.ts:63](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.configure.response.ts#L63)_
