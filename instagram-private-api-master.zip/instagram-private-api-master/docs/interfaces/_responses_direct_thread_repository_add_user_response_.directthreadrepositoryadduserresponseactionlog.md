> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/direct-thread.repository.add-user.response"](../modules/_responses_direct_thread_repository_add_user_response_.md) / [DirectThreadRepositoryAddUserResponseActionLog](_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponseactionlog.md) /

# Interface: DirectThreadRepositoryAddUserResponseActionLog

## Hierarchy

- **DirectThreadRepositoryAddUserResponseActionLog**

## Index

### Properties

- [bold](_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponseactionlog.md#bold)
- [description](_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponseactionlog.md#description)
- [text_attributes](_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponseactionlog.md#text_attributes)

## Properties

### bold

• **bold**: _[DirectThreadRepositoryAddUserResponseBoldItem](\_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponsebolditem.md)[]\_

_Defined in [responses/direct-thread.repository.add-user.response.ts:89](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.add-user.response.ts#L89)_

---

### description

• **description**: _string_

_Defined in [responses/direct-thread.repository.add-user.response.ts:88](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.add-user.response.ts#L88)_

---

### text_attributes

• **text_attributes**: _[DirectThreadRepositoryAddUserResponseTextAttributesItem](\_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponsetextattributesitem.md)[]\_

_Defined in [responses/direct-thread.repository.add-user.response.ts:90](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.add-user.response.ts#L90)_
