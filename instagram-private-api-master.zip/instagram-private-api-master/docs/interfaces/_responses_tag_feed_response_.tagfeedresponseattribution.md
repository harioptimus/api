> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/tag.feed.response"](../modules/_responses_tag_feed_response_.md) / [TagFeedResponseAttribution](_responses_tag_feed_response_.tagfeedresponseattribution.md) /

# Interface: TagFeedResponseAttribution

## Hierarchy

- **TagFeedResponseAttribution**

## Index

### Properties

- [name](_responses_tag_feed_response_.tagfeedresponseattribution.md#name)

## Properties

### name

• **name**: _string_

_Defined in [responses/tag.feed.response.ts:220](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/tag.feed.response.ts#L220)_
