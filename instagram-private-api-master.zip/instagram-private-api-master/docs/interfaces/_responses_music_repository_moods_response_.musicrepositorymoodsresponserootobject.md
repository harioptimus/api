> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/music.repository.moods.response"](../modules/_responses_music_repository_moods_response_.md) / [MusicRepositoryMoodsResponseRootObject](_responses_music_repository_moods_response_.musicrepositorymoodsresponserootobject.md) /

# Interface: MusicRepositoryMoodsResponseRootObject

## Hierarchy

- **MusicRepositoryMoodsResponseRootObject**

## Index

### Properties

- [items](_responses_music_repository_moods_response_.musicrepositorymoodsresponserootobject.md#items)
- [status](_responses_music_repository_moods_response_.musicrepositorymoodsresponserootobject.md#status)

## Properties

### items

• **items**: _[MusicRepositoryMoodsResponseItemsItem](\_responses_music_repository_moods_response_.musicrepositorymoodsresponseitemsitem.md)[]\_

_Defined in [responses/music.repository.moods.response.ts:2](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/music.repository.moods.response.ts#L2)_

---

### status

• **status**: _string_

_Defined in [responses/music.repository.moods.response.ts:3](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/music.repository.moods.response.ts#L3)_
