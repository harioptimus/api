> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/saved.feed.response"](../modules/_responses_saved_feed_response_.md) / [SavedFeedResponseRootObjectItem](_responses_saved_feed_response_.savedfeedresponserootobjectitem.md) /

# Interface: SavedFeedResponseRootObjectItem

## Hierarchy

- **SavedFeedResponseRootObjectItem**

## Index

### Properties

- [media](_responses_saved_feed_response_.savedfeedresponserootobjectitem.md#media)

## Properties

### media

• **media**: _[SavedFeedResponseMedia](\_responses_saved_feed_response_.savedfeedresponsemedia.md)\_

_Defined in [responses/saved.feed.response.ts:11](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/saved.feed.response.ts#L11)_
