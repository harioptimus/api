> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/upload.repository.photo.response"](../modules/_responses_upload_repository_photo_response_.md) / [UploadRepositoryPhotoResponseXsharing_nonces](_responses_upload_repository_photo_response_.uploadrepositoryphotoresponsexsharing_nonces.md) /

# Interface: UploadRepositoryPhotoResponseXsharing_nonces

## Hierarchy

- **UploadRepositoryPhotoResponseXsharing_nonces**
