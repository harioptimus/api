> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/fbsearch.repository.topsearch-flat.response"](../modules/_responses_fbsearch_repository_topsearch_flat_response_.md) / [FbsearchRepositoryTopsearchFlatResponseHeader_media](_responses_fbsearch_repository_topsearch_flat_response_.fbsearchrepositorytopsearchflatresponseheader_media.md) /

# Interface: FbsearchRepositoryTopsearchFlatResponseHeader_media

## Hierarchy

- **FbsearchRepositoryTopsearchFlatResponseHeader_media**
