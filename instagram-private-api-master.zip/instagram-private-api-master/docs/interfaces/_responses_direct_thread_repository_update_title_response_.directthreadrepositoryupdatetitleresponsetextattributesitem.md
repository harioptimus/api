> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/direct-thread.repository.update-title.response"](../modules/_responses_direct_thread_repository_update_title_response_.md) / [DirectThreadRepositoryUpdateTitleResponseTextAttributesItem](_responses_direct_thread_repository_update_title_response_.directthreadrepositoryupdatetitleresponsetextattributesitem.md) /

# Interface: DirectThreadRepositoryUpdateTitleResponseTextAttributesItem

## Hierarchy

- **DirectThreadRepositoryUpdateTitleResponseTextAttributesItem**

## Index

### Properties

- [bold](_responses_direct_thread_repository_update_title_response_.directthreadrepositoryupdatetitleresponsetextattributesitem.md#bold)
- [color](_responses_direct_thread_repository_update_title_response_.directthreadrepositoryupdatetitleresponsetextattributesitem.md#color)
- [end](_responses_direct_thread_repository_update_title_response_.directthreadrepositoryupdatetitleresponsetextattributesitem.md#end)
- [intent](_responses_direct_thread_repository_update_title_response_.directthreadrepositoryupdatetitleresponsetextattributesitem.md#intent)
- [start](_responses_direct_thread_repository_update_title_response_.directthreadrepositoryupdatetitleresponsetextattributesitem.md#start)

## Properties

### bold

• **bold**: _number_

_Defined in [responses/direct-thread.repository.update-title.response.ts:95](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.update-title.response.ts#L95)_

---

### color

• **color**: _string_

_Defined in [responses/direct-thread.repository.update-title.response.ts:96](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.update-title.response.ts#L96)_

---

### end

• **end**: _number_

_Defined in [responses/direct-thread.repository.update-title.response.ts:94](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.update-title.response.ts#L94)_

---

### intent

• **intent**: _string_

_Defined in [responses/direct-thread.repository.update-title.response.ts:97](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.update-title.response.ts#L97)_

---

### start

• **start**: _number_

_Defined in [responses/direct-thread.repository.update-title.response.ts:93](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.update-title.response.ts#L93)_
