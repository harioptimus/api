> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/tag.feed.response"](../modules/_responses_tag_feed_response_.md) / [TagFeedResponseHashtag](_responses_tag_feed_response_.tagfeedresponsehashtag.md) /

# Interface: TagFeedResponseHashtag

## Hierarchy

- **TagFeedResponseHashtag**

## Index

### Properties

- [id](_responses_tag_feed_response_.tagfeedresponsehashtag.md#id)
- [name](_responses_tag_feed_response_.tagfeedresponsehashtag.md#name)

## Properties

### id

• **id**: _string_

_Defined in [responses/tag.feed.response.ts:256](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/tag.feed.response.ts#L256)_

---

### name

• **name**: _string_

_Defined in [responses/tag.feed.response.ts:255](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/tag.feed.response.ts#L255)_
