> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/direct-thread.feed.response"](../modules/_responses_direct_thread_feed_response_.md) / [DirectThreadFeedResponseLast_seen_at](_responses_direct_thread_feed_response_.directthreadfeedresponselast_seen_at.md) /

# Interface: DirectThreadFeedResponseLast_seen_at

## Hierarchy

- **DirectThreadFeedResponseLast_seen_at**

## Index

### Properties

- [300687565](_responses_direct_thread_feed_response_.directthreadfeedresponselast_seen_at.md#300687565)

## Properties

### 300687565

• **300687565**: _[DirectThreadFeedResponse300687565](\_responses_direct_thread_feed_response_.directthreadfeedresponse300687565.md)\_

_Defined in [responses/direct-thread.feed.response.ts:58](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.feed.response.ts#L58)_
