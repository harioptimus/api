> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/timeline.feed.response"](../modules/_responses_timeline_feed_response_.md) / [TimelineFeedResponseImage_versions2](_responses_timeline_feed_response_.timelinefeedresponseimage_versions2.md) /

# Interface: TimelineFeedResponseImage_versions2

## Hierarchy

- **TimelineFeedResponseImage_versions2**

## Index

### Properties

- [candidates](_responses_timeline_feed_response_.timelinefeedresponseimage_versions2.md#candidates)

## Properties

### candidates

• **candidates**: _[TimelineFeedResponseCandidatesItem](\_responses_timeline_feed_response_.timelinefeedresponsecandidatesitem.md)[]\_

_Defined in [responses/timeline.feed.response.ts:100](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/timeline.feed.response.ts#L100)_
