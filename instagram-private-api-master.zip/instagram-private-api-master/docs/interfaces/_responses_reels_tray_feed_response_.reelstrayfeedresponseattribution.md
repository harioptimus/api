> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/reels-tray.feed.response"](../modules/_responses_reels_tray_feed_response_.md) / [ReelsTrayFeedResponseAttribution](_responses_reels_tray_feed_response_.reelstrayfeedresponseattribution.md) /

# Interface: ReelsTrayFeedResponseAttribution

## Hierarchy

- **ReelsTrayFeedResponseAttribution**

## Index

### Properties

- [name](_responses_reels_tray_feed_response_.reelstrayfeedresponseattribution.md#name)

## Properties

### name

• **name**: _string_

_Defined in [responses/reels-tray.feed.response.ts:205](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/reels-tray.feed.response.ts#L205)_
