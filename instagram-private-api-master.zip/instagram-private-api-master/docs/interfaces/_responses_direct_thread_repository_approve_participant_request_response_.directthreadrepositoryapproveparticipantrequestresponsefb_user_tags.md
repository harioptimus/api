> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/direct-thread.repository.approve-participant-request.response"](../modules/_responses_direct_thread_repository_approve_participant_request_response_.md) / [DirectThreadRepositoryApproveParticipantRequestResponseFb_user_tags](_responses_direct_thread_repository_approve_participant_request_response_.directthreadrepositoryapproveparticipantrequestresponsefb_user_tags.md) /

# Interface: DirectThreadRepositoryApproveParticipantRequestResponseFb_user_tags

## Hierarchy

- **DirectThreadRepositoryApproveParticipantRequestResponseFb_user_tags**

## Index

### Properties

- [in](_responses_direct_thread_repository_approve_participant_request_response_.directthreadrepositoryapproveparticipantrequestresponsefb_user_tags.md#in)

## Properties

### in

• **in**: _any[]_

_Defined in [responses/direct-thread.repository.approve-participant-request.response.ts:138](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.approve-participant-request.response.ts#L138)_
