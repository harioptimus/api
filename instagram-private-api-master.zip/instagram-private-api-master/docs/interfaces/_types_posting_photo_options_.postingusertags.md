> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/posting.photo.options"](../modules/_types_posting_photo_options_.md) / [PostingUsertags](_types_posting_photo_options_.postingusertags.md) /

# Interface: PostingUsertags

## Hierarchy

- **PostingUsertags**

## Index

### Properties

- [in](_types_posting_photo_options_.postingusertags.md#in)

## Properties

### in

• **in**: _`Array<object>`_

_Defined in [types/posting.photo.options.ts:14](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/types/posting.photo.options.ts#L14)_
