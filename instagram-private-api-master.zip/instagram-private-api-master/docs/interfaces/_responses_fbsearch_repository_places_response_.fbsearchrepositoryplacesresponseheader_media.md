> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/fbsearch.repository.places.response"](../modules/_responses_fbsearch_repository_places_response_.md) / [FbsearchRepositoryPlacesResponseHeader_media](_responses_fbsearch_repository_places_response_.fbsearchrepositoryplacesresponseheader_media.md) /

# Interface: FbsearchRepositoryPlacesResponseHeader_media

## Hierarchy

- **FbsearchRepositoryPlacesResponseHeader_media**
