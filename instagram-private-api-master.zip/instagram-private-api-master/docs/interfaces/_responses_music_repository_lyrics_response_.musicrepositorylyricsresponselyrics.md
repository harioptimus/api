> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/music.repository.lyrics.response"](../modules/_responses_music_repository_lyrics_response_.md) / [MusicRepositoryLyricsResponseLyrics](_responses_music_repository_lyrics_response_.musicrepositorylyricsresponselyrics.md) /

# Interface: MusicRepositoryLyricsResponseLyrics

## Hierarchy

- **MusicRepositoryLyricsResponseLyrics**

## Index

### Properties

- [phrases](_responses_music_repository_lyrics_response_.musicrepositorylyricsresponselyrics.md#phrases)

## Properties

### phrases

• **phrases**: _[MusicRepositoryLyricsResponsePhrasesItem](\_responses_music_repository_lyrics_response_.musicrepositorylyricsresponsephrasesitem.md)[]\_

_Defined in [responses/music.repository.lyrics.response.ts:6](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/music.repository.lyrics.response.ts#L6)_
