> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/direct-thread.repository.add-user.response"](../modules/_responses_direct_thread_repository_add_user_response_.md) / [DirectThreadRepositoryAddUserResponseBoldItem](_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponsebolditem.md) /

# Interface: DirectThreadRepositoryAddUserResponseBoldItem

## Hierarchy

- **DirectThreadRepositoryAddUserResponseBoldItem**

## Index

### Properties

- [end](_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponsebolditem.md#end)
- [start](_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponsebolditem.md#start)

## Properties

### end

• **end**: _number_

_Defined in [responses/direct-thread.repository.add-user.response.ts:95](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.add-user.response.ts#L95)_

---

### start

• **start**: _number_

_Defined in [responses/direct-thread.repository.add-user.response.ts:94](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.add-user.response.ts#L94)_
