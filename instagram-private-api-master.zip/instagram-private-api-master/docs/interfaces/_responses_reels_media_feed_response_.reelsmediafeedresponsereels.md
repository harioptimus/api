> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/reels-media.feed.response"](../modules/_responses_reels_media_feed_response_.md) / [ReelsMediaFeedResponseReels](_responses_reels_media_feed_response_.reelsmediafeedresponsereels.md) /

# Interface: ReelsMediaFeedResponseReels

## Hierarchy

- **ReelsMediaFeedResponseReels**

## Indexable

● \[▪ **pk**: _string_\]: [ReelsMediaFeedResponse](_responses_reels_media_feed_response_.reelsmediafeedresponse.md)
