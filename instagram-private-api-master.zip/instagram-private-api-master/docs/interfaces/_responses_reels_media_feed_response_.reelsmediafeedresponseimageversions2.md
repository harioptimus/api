> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/reels-media.feed.response"](../modules/_responses_reels_media_feed_response_.md) / [ReelsMediaFeedResponseImageVersions2](_responses_reels_media_feed_response_.reelsmediafeedresponseimageversions2.md) /

# Interface: ReelsMediaFeedResponseImageVersions2

## Hierarchy

- **ReelsMediaFeedResponseImageVersions2**

## Index

### Properties

- [candidates](_responses_reels_media_feed_response_.reelsmediafeedresponseimageversions2.md#candidates)

## Properties

### candidates

• **candidates**: _[ReelsMediaFeedResponseCandidatesItem](\_responses_reels_media_feed_response_.reelsmediafeedresponsecandidatesitem.md)[]\_

_Defined in [responses/reels-media.feed.response.ts:78](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/reels-media.feed.response.ts#L78)_
