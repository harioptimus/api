> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/location.feed.response"](../modules/_responses_location_feed_response_.md) / [LocationFeedResponseLayout_content](_responses_location_feed_response_.locationfeedresponselayout_content.md) /

# Interface: LocationFeedResponseLayout_content

## Hierarchy

- **LocationFeedResponseLayout_content**

## Index

### Properties

- [medias](_responses_location_feed_response_.locationfeedresponselayout_content.md#medias)

## Properties

### medias

• **medias**: _[LocationFeedResponseMediasItem](\_responses_location_feed_response_.locationfeedresponsemediasitem.md)[]\_

_Defined in [responses/location.feed.response.ts:16](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/location.feed.response.ts#L16)_
