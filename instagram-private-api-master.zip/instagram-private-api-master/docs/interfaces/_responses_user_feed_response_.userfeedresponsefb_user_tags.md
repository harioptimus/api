> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/user.feed.response"](../modules/_responses_user_feed_response_.md) / [UserFeedResponseFb_user_tags](_responses_user_feed_response_.userfeedresponsefb_user_tags.md) /

# Interface: UserFeedResponseFb_user_tags

## Hierarchy

- **UserFeedResponseFb_user_tags**

## Index

### Properties

- [in](_responses_user_feed_response_.userfeedresponsefb_user_tags.md#in)

## Properties

### in

• **in**: _any[]_

_Defined in [responses/user.feed.response.ts:90](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/user.feed.response.ts#L90)_
