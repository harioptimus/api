> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/saved.feed.response"](../modules/_responses_saved_feed_response_.md) / [SavedFeedResponseImage_versions2](_responses_saved_feed_response_.savedfeedresponseimage_versions2.md) /

# Interface: SavedFeedResponseImage_versions2

## Hierarchy

- **SavedFeedResponseImage_versions2**

## Index

### Properties

- [candidates](_responses_saved_feed_response_.savedfeedresponseimage_versions2.md#candidates)

## Properties

### candidates

• **candidates**: _[SavedFeedResponseCandidatesItem](\_responses_saved_feed_response_.savedfeedresponsecandidatesitem.md)[]\_

_Defined in [responses/saved.feed.response.ts:87](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/saved.feed.response.ts#L87)_
