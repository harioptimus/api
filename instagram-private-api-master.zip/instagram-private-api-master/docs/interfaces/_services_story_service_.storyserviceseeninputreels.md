> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["services/story.service"](../modules/_services_story_service_.md) / [StoryServiceSeenInputReels](_services_story_service_.storyserviceseeninputreels.md) /

# Interface: StoryServiceSeenInputReels

## Hierarchy

- **StoryServiceSeenInputReels**

## Index

### Properties

- [items](_services_story_service_.storyserviceseeninputreels.md#items)

## Properties

### items

• **items**: _[StoryServiceSeenInputItems](\_services_story_service_.storyserviceseeninputitems.md)[]\_

_Defined in [services/story.service.ts:12](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/services/story.service.ts#L12)_
