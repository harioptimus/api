> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/direct-thread.repository.get-by-participants.response"](../modules/_responses_direct_thread_repository_get_by_participants_response_.md) / [DirectThreadRepositoryGetByParticipantsResponseRootObject](_responses_direct_thread_repository_get_by_participants_response_.directthreadrepositorygetbyparticipantsresponserootobject.md) /

# Interface: DirectThreadRepositoryGetByParticipantsResponseRootObject

## Hierarchy

- **DirectThreadRepositoryGetByParticipantsResponseRootObject**

## Index

### Properties

- [status](_responses_direct_thread_repository_get_by_participants_response_.directthreadrepositorygetbyparticipantsresponserootobject.md#status)
- [thread](_responses_direct_thread_repository_get_by_participants_response_.directthreadrepositorygetbyparticipantsresponserootobject.md#thread)

## Properties

### status

• **status**: _string_

_Defined in [responses/direct-thread.repository.get-by-participants.response.ts:3](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.get-by-participants.response.ts#L3)_

---

### thread

• **thread**: _[DirectThreadRepositoryGetByParticipantsResponseThread](\_responses_direct_thread_repository_get_by_participants_response_.directthreadrepositorygetbyparticipantsresponsethread.md)\_

_Defined in [responses/direct-thread.repository.get-by-participants.response.ts:2](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/direct-thread.repository.get-by-participants.response.ts#L2)_
