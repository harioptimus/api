> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/timeline.feed.response"](../modules/_responses_timeline_feed_response_.md) / [TimelineFeedResponseAdMetadataItem](_responses_timeline_feed_response_.timelinefeedresponseadmetadataitem.md) /

# Interface: TimelineFeedResponseAdMetadataItem

## Hierarchy

- **TimelineFeedResponseAdMetadataItem**

## Index

### Properties

- [type](_responses_timeline_feed_response_.timelinefeedresponseadmetadataitem.md#type)
- [value](_responses_timeline_feed_response_.timelinefeedresponseadmetadataitem.md#value)

## Properties

### type

• **type**: _number_

_Defined in [responses/timeline.feed.response.ts:177](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/timeline.feed.response.ts#L177)_

---

### value

• **value**: _string_

_Defined in [responses/timeline.feed.response.ts:176](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/timeline.feed.response.ts#L176)_
