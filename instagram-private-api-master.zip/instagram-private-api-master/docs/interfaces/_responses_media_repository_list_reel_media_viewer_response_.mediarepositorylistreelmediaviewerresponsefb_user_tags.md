> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/media.repository.list-reel-media-viewer.response"](../modules/_responses_media_repository_list_reel_media_viewer_response_.md) / [MediaRepositoryListReelMediaViewerResponseFb_user_tags](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponsefb_user_tags.md) /

# Interface: MediaRepositoryListReelMediaViewerResponseFb_user_tags

## Hierarchy

- **MediaRepositoryListReelMediaViewerResponseFb_user_tags**

## Index

### Properties

- [in](_responses_media_repository_list_reel_media_viewer_response_.mediarepositorylistreelmediaviewerresponsefb_user_tags.md#in)

## Properties

### in

• **in**: _any[]_

_Defined in [responses/media.repository.list-reel-media-viewer.response.ts:92](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/media.repository.list-reel-media-viewer.response.ts#L92)_
