> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/user.feed.response"](../modules/_responses_user_feed_response_.md) / [UserFeedResponseImage_versions2](_responses_user_feed_response_.userfeedresponseimage_versions2.md) /

# Interface: UserFeedResponseImage_versions2

## Hierarchy

- **UserFeedResponseImage_versions2**

## Index

### Properties

- [candidates](_responses_user_feed_response_.userfeedresponseimage_versions2.md#candidates)

## Properties

### candidates

• **candidates**: _[UserFeedResponseCandidatesItem](\_responses_user_feed_response_.userfeedresponsecandidatesitem.md)[]\_

_Defined in [responses/user.feed.response.ts:57](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/user.feed.response.ts#L57)_
