> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/live.switch-comments.response"](../modules/_responses_live_switch_comments_response_.md) / [LiveSwitchCommentsResponseRootObject](_responses_live_switch_comments_response_.liveswitchcommentsresponserootobject.md) /

# Interface: LiveSwitchCommentsResponseRootObject

## Hierarchy

- **LiveSwitchCommentsResponseRootObject**

## Index

### Properties

- [comment_muted](_responses_live_switch_comments_response_.liveswitchcommentsresponserootobject.md#comment_muted)
- [status](_responses_live_switch_comments_response_.liveswitchcommentsresponserootobject.md#status)

## Properties

### comment_muted

• **comment_muted**: _number_

_Defined in [responses/live.switch-comments.response.ts:2](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/live.switch-comments.response.ts#L2)_

---

### status

• **status**: _string_

_Defined in [responses/live.switch-comments.response.ts:3](https://github.com/realinstadude/instagram-private-api/blob/4ae8fec/src/responses/live.switch-comments.response.ts#L3)_
